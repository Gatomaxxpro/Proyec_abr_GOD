/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cod_generico;

import java.util.ArrayList;

/**
 *
 * @author HP AiO
 */
public class Proveedor {
    
private String nombre;
    private String direccion;
    private String telefono;

    // Constructor
    public Proveedor(String nombre, String direccion, String telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    // Métodos para acceder y modificar los atributos
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    // Método para imprimir los detalles del proveedor
    public void mostrarDetalles() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Dirección: " + direccion);
        System.out.println("Teléfono: " + telefono);
    }
}

// Clase para manejar el registro de proveedores
class RegistroProveedores {
    private final ArrayList<Proveedor> proveedores;

    // Constructor
    public RegistroProveedores() {
        this.proveedores = new ArrayList<>();
    }

    // Método para agregar un nuevo proveedor al registro
    public void agregarProveedor(Proveedor proveedor) {
        proveedores.add(proveedor);
    }

    // Método para mostrar todos los proveedores en el registro
    public void mostrarProveedores() {
        for (Proveedor proveedor : proveedores) {
            proveedor.mostrarDetalles();
            System.out.println("-------------------------");
        }
    }
}

// Clase principal para probar el registro de proveedores
